import React from 'react';

import moment from 'moment-jalaali';
import { useLocale } from 'next-intl';

import {
  DynamicSelect,
  NewDatePicker,
} from '@components/atoms/defaultElements';
import { IRequestConfig } from '@type/elementType';

import { UITableController } from '../adapters/ui/UITableController';
import { FieldType } from '../bootstrap/type';
import { RowStateEnum } from '../domain/value-objects';
import {
  ItemType,
  TCell,
} from '../engine/type';

/* ======================================================
   Types
   ====================================================== */

export type CellMeta = {
  renderType: FieldType;
  editable?: boolean;
  expandable?: boolean;
  options?: { label: string; value: string }[];
  dynamicValue?: IRequestConfig;
  // store: string;
  // tableKey: string;
  tableId: string;
  columnId: string;
  indexOptions?: (
    tableId: string,
    rowId: number,
    row: {
      id: string | number;
      cells: Record<string, TCell>;
      rowState: RowStateEnum;
      isExpanded: boolean;
    },
    controller: UITableController,
  ) => ItemType[];
};

interface CellRendererProps {
  tableKey: string;
  row: {
    id: number;
    cells: Record<string, TCell>;
    rowState: RowStateEnum;
    isExpanded: boolean;
  };
  columnId: string;
  idx: number;
  meta?: CellMeta;
  controller: UITableController;
  tabIndex: number;
}

/* ======================================================
   Cell Renderer
   ====================================================== */

export const CellRenderer: React.FC<CellRendererProps> = ({
  tableKey,
  row,
  columnId,
  meta,
  controller,
  tabIndex,
  idx,
}) => {
  const viewCell = controller.getCell(tableKey, row.id, columnId);
  const value = viewCell.getValue().value;
  const display = viewCell.getDisplay().value;
  const isActive = controller.isActiveCell(tableKey, row.id, columnId);

  const locale = useLocale();
  const dispatchChangeValue = (newValue: unknown) => {
    controller.dispatch({
      type: "UI_CELL_CHANGE",
      rowId: row.id,
      columnId,
      value: newValue,
    });
  };
  const dispatchChangeDisplay = (label: string | null) => {
    controller.dispatch({
      type: "UI_CELL_CHANGE_DISPLAY",
      rowId: row.id,
      columnId,
      value: label,
    });
  };
  const activeCell = () => {
    controller.dispatch({ type: "UI_ACTIVE_CELL", rowId: row.id, columnId });
  };

  const type = meta.renderType;
  const editable = meta.editable;
  const isDeleted = row.rowState === RowStateEnum.Deleted;

  const blockDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };
  const valueParser = (val) => {
    if (val == null || val == undefined) {
      return "—";
    }
    switch (type) {
      case "text":
      case "number":
      case "select":
      case "selectOption":
      case "static":
        return val;

      case "date":
        if (locale === "fa") {
          return moment(val).format("jYYYY/jMM/jDD");
        } else {
          return moment(val).format("YYYY/MM/DD");
        }

      default:
        return "—";
    }
  };

  if (editable == false || type == "index") {
    return <span key={idx} className="text-xs">{String(value ?? "")}</span>;
  }
  /* ===== view mode ===== */
  if (!isActive || isDeleted) {
    return (
      <button
        key={idx}
        tabIndex={tabIndex}
        disabled={isDeleted}
        className={`flex items-center  px-2 w-full h-full text-xs ${isDeleted ? "cursor-not-allowed " : "cursor-text"}`}
        onClick={() => {
          activeCell();
        }}
      >
        {valueParser(display ?? value)}
      </button>
    );
  }

  /* ===== edit mode ===== */
  switch (type) {
    case "number":
      return (
        <input
          key={idx}
          autoFocus
          value={value === "" || value == null ? "" : Number(value)}
          disabled={isDeleted || !editable}
          className={`${isDeleted && "cursor-not-allowed"}
          flex items-center bg-transparent px-3 outline-none 
          focus-visible:outline-none focus:outline-none ring-0 focus:!ring-0 
          focus:ring-offset-0 w-36 h-8 text-xs transition-colors ]`}
          draggable={false}
          onDragStart={blockDrag}
          onDragOver={blockDrag}
          onDrop={blockDrag}
          onChange={(e) =>
            dispatchChangeValue(
              e.target.value === "" ? "" : Number(e.target.value),
            )
          }
        />
      );

    case "date":
      return (
        <NewDatePicker
          key={idx}
          disabled={isDeleted || !editable}
          value={value ? new Date(value as string).valueOf() : undefined}
          onChange={(v) => {
            dispatchChangeValue(v);
          }}
        />
      );

    case "select":
      return (
        <select
          key={idx}
          disabled={isDeleted || !editable}
          className={`!w-36 h-8 ${isDeleted && "cursor-not-allowed"}`}
          value={String(value ?? "")}
          onClick={() => activeCell()}
          onChange={(e) => {
            dispatchChangeValue(e.target.value);
          }}
        >
          <option value="" />
          {(meta?.options ?? []).map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
      );

    case "selectOption":
      return (
        <DynamicSelect
          key={idx}
          showSearch
          onSearchPhrase={(v, o) => {
            dispatchChangeValue(v);
            if (!Array.isArray(o)) {
              if (o) {
                dispatchChangeDisplay(o);
              } else {
                console.log("change display to null");
                dispatchChangeDisplay(null);
              }
            }
          }}
          autoFocus
          disabled={isDeleted || !editable}
          value={{ value: String(value ?? ""), label: display }}
          dynamicValue={meta?.dynamicValue}
          className={`!bg-white !border-[0.4px] !border-gray-gray7 !w-36 h-8 ${isDeleted && "cursor-not-allowed"} relative`}
          infinite
          onClick={() => activeCell()}
          onChange={(v, o) => {
            dispatchChangeValue(v);
            if (!Array.isArray(o)) {
              if (o?.label) {
                dispatchChangeDisplay(o.label as string);
              } else {
                console.log("change display to null");
                dispatchChangeDisplay(null);
              }
            }
          }}
        />
      );
    case "static":
      return (
        <span
        key={idx}
          tabIndex={tabIndex}
          className="flex items-center px-2 w-full h-full text-xs cursor-text"
          onClick={() => activeCell()}
        >
          {String(display ?? value ?? "") || "—"}
        </span>
      );
    case "text":
    default:
      return (
        <input
         key={idx}
          // autoFocus
          disabled={isDeleted || !editable}
          value={value == null ? "" : String(value)}
          className={`${isDeleted && "cursor-not-allowed"}
            flex items-center bg-transparent px-2 outline-none focus-visible:outline-none
           focus:outline-none ring-0 focus:!ring-0 focus:ring-offset-0 w-36 h-8 transition-colors ]`}
          draggable={false}
          onDragStart={blockDrag}
          onDragOver={blockDrag}
          onDrop={blockDrag}
          onChange={(e) => dispatchChangeValue(e.target.value)}
          onClick={() => activeCell()}
        />
      );
  }
};
